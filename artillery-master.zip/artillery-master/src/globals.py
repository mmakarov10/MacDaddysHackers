# Artillery - globals

global g_apppath
global g_appfile
global g_configfile
global g_banlist
global g_localbanlist
